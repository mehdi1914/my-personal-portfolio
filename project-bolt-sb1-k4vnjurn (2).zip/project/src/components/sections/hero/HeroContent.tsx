import React from 'react';
import { motion } from 'framer-motion';
import TypewriterText from './TypewriterText';
import SocialLinks from './SocialLinks';
import ActionButtons from './ActionButtons';

export default function HeroContent() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      className="space-y-8"
    >
      <motion.h1 
        className="text-4xl md:text-6xl lg:text-7xl font-bold text-white"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.2 }}
      >
        Hi, I'm <TypewriterText />
      </motion.h1>
      
      <motion.p 
        className="text-xl md:text-2xl text-purple-200/90"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.4 }}
      >
        Building Founder-Focused Digital Experiences
      </motion.p>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.6 }}
      >
        <ActionButtons />
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.8 }}
      >
        <SocialLinks />
      </motion.div>
    </motion.div>
  );
}